import { useState } from "react"

const DICAS = [
  { cat: "Poupança", text: "Separe 10% da sua renda assim que receber. Pague-se primeiro, antes de qualquer conta." },
  { cat: "Dívidas", text: "Se tiver dívidas com juros altos, priorize quitá-las antes de investir. Dívida cara come qualquer lucro." },
  { cat: "Renda baixa", text: "Com pouco dinheiro, o melhor investimento é você mesmo: cursos gratuitos podem dobrar sua renda." },
  { cat: "Poupança", text: "Crie um fundo de emergência de pelo menos 3 meses de despesas antes de pensar em qualquer outro investimento." },
  { cat: "Cotidiano", text: "Anote tudo que gasta por 30 dias. Você vai se surpreender com quanto vai embora em pequenas compras." },
  { cat: "Renda baixa", text: "Busque renegociar seus contratos anuais: internet, planos de celular, seguros. Pequenas economias somam muito." },
  { cat: "Investimentos", text: "Tesouro Direto e CDBs de bancos digitais podem render mais que a poupança com o mesmo nível de segurança." },
  { cat: "Cotidiano", text: "Evite compras por impulso: espere 48h antes de comprar qualquer coisa acima de R$50 que não estava no plano." },
  { cat: "Renda baixa", text: "Aproveite programas do governo como Bolsa Família, Desenrola Brasil e FIES para educação e regularização financeira." },
  { cat: "Investimentos", text: "Não precisa de muito para começar a investir. Com R$30 você já pode comprar frações de ações na bolsa." },
]

export default function Dicas() {
  const [filter, setFilter] = useState("Todas")
  const cats = ["Todas", ...new Set(DICAS.map(d => d.cat))]
  const filtered = filter === "Todas" ? DICAS : DICAS.filter(d => d.cat === filter)

  return (
    <div>
      <div style={{ marginBottom: 16 }}>
        <h2 style={{ fontSize: 22, fontWeight: 600, color: "#1a2e26" }}>Dicas Financeiras</h2>
        <p style={{ fontSize: 13, color: "#5a7a6e" }}>Curadas para sua realidade</p>
      </div>

      <div style={{ display: "flex", gap: 8, overflowX: "auto", marginBottom: 16, paddingBottom: 4, scrollbarWidth: "none" }}>
        {cats.map(c => (
          <button key={c} onClick={() => setFilter(c)}
            style={{ border: `0.5px solid ${filter === c ? "#2C5545" : "rgba(44,85,69,0.2)"}`, borderRadius: 20, padding: "5px 14px", fontSize: 12, color: filter === c ? "#fff" : "#5a7a6e", background: filter === c ? "#2C5545" : "#fff", cursor: "pointer", whiteSpace: "nowrap", fontFamily: "inherit" }}>
            {c}
          </button>
        ))}
      </div>

      {filtered.map((d, i) => (
        <div key={i} style={{ background: "#fff", border: "0.5px solid rgba(44,85,69,0.15)", borderRadius: 12, padding: 14, marginBottom: 10 }}>
          <div style={{ fontSize: 10, fontWeight: 500, color: "#C86A53", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 6 }}>{d.cat}</div>
          <div style={{ fontSize: 14, color: "#1a2e26", lineHeight: 1.6 }}>{d.text}</div>
        </div>
      ))}
    </div>
  )
}
