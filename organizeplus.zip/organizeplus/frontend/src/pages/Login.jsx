import { useState } from "react"
import { useAuth } from "../App"

export default function Login() {
  const { login } = useAuth()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)

  const handle = async (e) => {
    e.preventDefault()
    if (!name || !email) return
    setLoading(true)
    await login(name, email)
    setLoading(false)
  }

  return (
    <div style={{ minHeight: "100vh", background: "#2C5545", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 24, fontFamily: "Outfit, sans-serif" }}>
      <div style={{ marginBottom: 32, textAlign: "center" }}>
        <h1 style={{ color: "#fff", fontFamily: "Manrope, sans-serif", fontSize: 36, fontWeight: 700, margin: 0 }}>Organize<span style={{ color: "#a8d4bc" }}>+</span></h1>
        <p style={{ color: "#a8d4bc", marginTop: 8, fontSize: 15 }}>Organize sua vida financeira</p>
      </div>
      <div style={{ background: "#FAF9F6", borderRadius: 20, padding: 28, width: "100%", maxWidth: 380 }}>
        <h2 style={{ color: "#1a2e26", fontSize: 18, fontWeight: 600, marginBottom: 20 }}>Entrar na conta</h2>
        <form onSubmit={handle}>
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, color: "#5a7a6e", display: "block", marginBottom: 4 }}>Seu nome</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="João Silva"
              style={{ width: "100%", padding: "10px 12px", border: "0.5px solid rgba(44,85,69,0.2)", borderRadius: 8, fontSize: 14, fontFamily: "inherit", outline: "none", color: "#1a2e26" }} />
          </div>
          <div style={{ marginBottom: 20 }}>
            <label style={{ fontSize: 12, color: "#5a7a6e", display: "block", marginBottom: 4 }}>E-mail</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="joao@email.com"
              style={{ width: "100%", padding: "10px 12px", border: "0.5px solid rgba(44,85,69,0.2)", borderRadius: 8, fontSize: 14, fontFamily: "inherit", outline: "none", color: "#1a2e26" }} />
          </div>
          <button type="submit" disabled={loading}
            style={{ width: "100%", background: "#2C5545", color: "#fff", border: "none", borderRadius: 10, padding: 13, fontSize: 15, fontWeight: 500, cursor: "pointer", fontFamily: "inherit", opacity: loading ? 0.7 : 1 }}>
            {loading ? "Entrando..." : "Entrar →"}
          </button>
        </form>
        <p style={{ textAlign: "center", fontSize: 11, color: "#5a7a6e", marginTop: 16 }}>Seus dados ficam salvos com segurança</p>
      </div>
    </div>
  )
}
