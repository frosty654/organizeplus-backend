# Organize+ 🌿

App de organização financeira para brasileiros. Coach com IA (Claude), metas, dicas e biblioteca.

## Estrutura
```
organizeplus/
├── backend/        # FastAPI + MongoDB
└── frontend/       # React 19 + Vite
```

---

## 🚀 Deploy Gratuito (Railway + Vercel)

### 1. Backend no Railway

1. Acesse [railway.app](https://railway.app) e crie conta
2. Clique em **New Project → Deploy from GitHub**
3. Suba a pasta `backend/` num repositório GitHub
4. Na aba **Variables**, adicione:
   - `MONGO_URL` → crie um MongoDB no Railway (Add Service → MongoDB) e copie a URL
   - `ANTHROPIC_API_KEY` → sua chave da [console.anthropic.com](https://console.anthropic.com)
5. O Railway detecta o `Procfile` e sobe automaticamente
6. Copie a URL do projeto (ex: `https://organizeplus-backend.up.railway.app`)

### 2. Frontend na Vercel

1. Acesse [vercel.com](https://vercel.com) e crie conta
2. Importe o repositório com a pasta `frontend/`
3. Nas configurações do projeto:
   - **Root Directory**: `frontend`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
4. Em **Environment Variables**, adicione:
   - `VITE_API_URL` = URL do seu backend Railway
5. Clique em **Deploy**

---

## 💻 Rodar Localmente

### Backend
```bash
cd backend
pip install -r requirements.txt
MONGO_URL=mongodb://localhost:27017 ANTHROPIC_API_KEY=sk-ant-... uvicorn main:app --reload
```

### Frontend
```bash
cd frontend
npm install
cp .env.example .env
# Edite .env com VITE_API_URL=http://localhost:8000
npm run dev
```

Acesse: http://localhost:3000

---

## 🔑 Variáveis de Ambiente

| Variável | Onde usar | Descrição |
|---|---|---|
| `MONGO_URL` | Backend | URL do MongoDB |
| `ANTHROPIC_API_KEY` | Backend | Chave da API Anthropic |
| `VITE_API_URL` | Frontend | URL do backend |

---

## 📱 Funcionalidades

- **Dashboard** — metas, dica do dia, livros recomendados
- **Metas** — CRUD completo com progresso visual
- **Dicas** — 10 dicas curadas por categoria
- **Coach IA** — Claude Sonnet com streaming e histórico
